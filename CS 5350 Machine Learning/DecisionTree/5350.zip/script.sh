python3 DecisionTree.py
