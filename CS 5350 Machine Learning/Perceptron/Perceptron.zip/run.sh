python3 perceptron.py
